package com.skcet.events_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
