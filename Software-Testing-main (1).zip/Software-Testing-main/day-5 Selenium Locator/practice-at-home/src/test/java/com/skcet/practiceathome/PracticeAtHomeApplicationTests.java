package com.skcet.practiceathome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeAtHomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
